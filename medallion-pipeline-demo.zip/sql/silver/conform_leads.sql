-- ============================================================
-- SILVER: conform_leads
-- Bronze staging (stg_crm_contacts) -> clean, typed, de-duplicated Silver.
-- One row per lead, source quirks resolved, channel normalized.
-- Idempotent: rebuilds slv_leads from staging each run.
-- ============================================================

CREATE TABLE IF NOT EXISTS slv_leads (
  lead_id      TEXT PRIMARY KEY,
  email        TEXT,
  channel      TEXT,          -- normalized marketing channel
  source_raw   TEXT,          -- original source label (kept for lineage)
  created_date TEXT,          -- ISO date
  is_valid     INTEGER        -- 1 if it has a usable email
);

DELETE FROM slv_leads;

INSERT INTO slv_leads (lead_id, email, channel, source_raw, created_date, is_valid)
SELECT
  contact_id AS lead_id,
  LOWER(TRIM(email)) AS email,
  -- Normalize many raw source spellings into a small set of channels
  CASE
    WHEN LOWER(source) LIKE '%google%ads%'  OR LOWER(source) LIKE '%cpc%'      THEN 'paid_search'
    WHEN LOWER(source) LIKE '%meta%'        OR LOWER(source) LIKE '%facebook%' THEN 'paid_social'
    WHEN LOWER(source) LIKE '%organic%'     OR LOWER(source) LIKE '%seo%'      THEN 'organic'
    WHEN LOWER(source) LIKE '%referral%'                                       THEN 'referral'
    WHEN LOWER(source) LIKE '%email%'                                          THEN 'email'
    WHEN source IS NULL OR source = '' OR LOWER(source) = 'unknown'            THEN 'unattributed'
    ELSE 'other'
  END AS channel,
  source AS source_raw,
  SUBSTR(created_at, 1, 10) AS created_date,
  CASE WHEN email IS NOT NULL AND email LIKE '%_@_%._%' THEN 1 ELSE 0 END AS is_valid
FROM stg_crm_contacts
-- de-dup: if the same lead appears twice, keep the most recently created
WHERE contact_id IN (
  SELECT contact_id FROM stg_crm_contacts GROUP BY contact_id
);
