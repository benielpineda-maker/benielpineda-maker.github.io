-- ============================================================
-- GOLD: lead performance marts
-- Business-facing views composed from Silver. Read-only; a dashboard
-- selects straight from these. Defined as views so they always reflect
-- the latest Silver without a rebuild step.
-- ============================================================

-- Leads by channel, by day — the core marketing mart.
DROP VIEW IF EXISTS gld_lead_performance;
CREATE VIEW gld_lead_performance AS
SELECT
  created_date,
  channel,
  COUNT(*)                                   AS leads,
  SUM(is_valid)                              AS valid_leads,
  ROUND(100.0 * SUM(is_valid) / COUNT(*), 1) AS valid_rate_pct
FROM slv_leads
WHERE created_date IS NOT NULL
GROUP BY created_date, channel;

-- Channel ROI: joins lead volume to ad spend (slv_ad_spend_daily lives in the
-- spend pipeline; shown here as the intended shape of the mart).
DROP VIEW IF EXISTS gld_channel_roi;
CREATE VIEW gld_channel_roi AS
SELECT
  lp.channel,
  SUM(lp.leads)                                           AS leads,
  COALESCE(SUM(sp.spend_usd), 0)                          AS spend_usd,
  CASE WHEN SUM(lp.leads) > 0
       THEN ROUND(COALESCE(SUM(sp.spend_usd), 0) / SUM(lp.leads), 2)
       ELSE NULL END                                      AS cost_per_lead
FROM gld_lead_performance lp
LEFT JOIN slv_ad_spend_daily sp
  ON sp.channel = lp.channel AND sp.spend_date = lp.created_date
GROUP BY lp.channel;
