/**
 * Bronze extractor — CRM contacts.
 *
 * Pulls contacts from a CRM API (paginated) and lands the raw payloads, unmodified,
 * into the Bronze lake in R2 as newline-delimited JSON under:
 *
 *     bronze/crm_contacts/dt=YYYY-MM-DD/page-<n>.jsonl
 *
 * Bronze is immutable: we never clean or reshape here. Conforming happens in Silver.
 */

export interface Env {
  BRONZE: R2Bucket;
  CRM_API_TOKEN: string; // set via `wrangler secret put CRM_API_TOKEN`
}

const CRM_BASE_URL = "https://api.example-crm.test/v1";
const PAGE_SIZE = 100;

interface CrmContactPage {
  results: unknown[];
  paging?: { next?: { after: string } };
}

async function fetchPage(env: Env, after?: string): Promise<CrmContactPage> {
  const url = new URL(`${CRM_BASE_URL}/contacts`);
  url.searchParams.set("limit", String(PAGE_SIZE));
  if (after) url.searchParams.set("after", after);

  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${env.CRM_API_TOKEN}` },
  });
  if (!res.ok) {
    throw new Error(`CRM API ${res.status}: ${await res.text()}`);
  }
  return (await res.json()) as CrmContactPage;
}

function bronzeKey(page: number): string {
  const dt = new Date().toISOString().slice(0, 10); // YYYY-MM-DD
  return `bronze/crm_contacts/dt=${dt}/page-${String(page).padStart(4, "0")}.jsonl`;
}

/** Extract all contact pages and write each to Bronze as raw JSONL. */
export async function extractCrmContacts(env: Env): Promise<{ pages: number; records: number }> {
  let after: string | undefined;
  let page = 0;
  let records = 0;

  do {
    const data = await fetchPage(env, after);
    const jsonl = data.results.map((r) => JSON.stringify(r)).join("\n");

    await env.BRONZE.put(bronzeKey(page), jsonl, {
      httpMetadata: { contentType: "application/x-ndjson" },
    });

    records += data.results.length;
    after = data.paging?.next?.after;
    page += 1;
  } while (after);

  return { pages: page, records };
}

export default {
  async scheduled(_event: ScheduledEvent, env: Env, ctx: ExecutionContext): Promise<void> {
    ctx.waitUntil(
      extractCrmContacts(env).then((r) =>
        console.log(`[bronze] crm_contacts: ${r.records} records across ${r.pages} pages`)
      )
    );
  },
};
