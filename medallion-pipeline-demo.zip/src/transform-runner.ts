/**
 * Transform runner — orchestrates the Silver and Gold layers.
 *
 * Runs on a nightly cron. Reads the day's Bronze objects from R2, loads them into a
 * Silver staging table in D1, then executes the conform (Silver) and model (Gold) SQL.
 *
 * Every step is idempotent: a given day always re-derives the same rows, so retries and
 * backfills are safe.
 */

import conformLeads from "../sql/silver/conform_leads.sql";
import martLeadPerformance from "../sql/gold/mart_lead_performance.sql";

export interface Env {
  BRONZE: R2Bucket;
  WAREHOUSE: D1Database;
}

/** Read all Bronze JSONL for a source/date and parse into records. */
async function readBronze(env: Env, source: string, dt: string): Promise<any[]> {
  const prefix = `bronze/${source}/dt=${dt}/`;
  const listed = await env.BRONZE.list({ prefix });
  const records: any[] = [];

  for (const obj of listed.objects) {
    const body = await env.BRONZE.get(obj.key);
    if (!body) continue;
    const text = await body.text();
    for (const line of text.split("\n")) {
      if (line.trim()) records.push(JSON.parse(line));
    }
  }
  return records;
}

/** Stage raw contacts into Silver's landing table (replace-on-key, so re-runs are clean). */
async function stageContacts(env: Env, dt: string): Promise<number> {
  const rows = await readBronze(env, "crm_contacts", dt);

  await env.WAREHOUSE.prepare(
    `CREATE TABLE IF NOT EXISTS stg_crm_contacts (
       contact_id TEXT PRIMARY KEY,
       email TEXT, source TEXT, created_at TEXT, raw TEXT, dt TEXT
     )`
  ).run();

  const stmt = env.WAREHOUSE.prepare(
    `INSERT INTO stg_crm_contacts (contact_id, email, source, created_at, raw, dt)
     VALUES (?1, ?2, ?3, ?4, ?5, ?6)
     ON CONFLICT(contact_id) DO UPDATE SET
       email=excluded.email, source=excluded.source,
       created_at=excluded.created_at, raw=excluded.raw, dt=excluded.dt`
  );

  const batch = rows.map((r) =>
    stmt.bind(
      String(r.id),
      r.properties?.email ?? null,
      r.properties?.source ?? "unknown",
      r.properties?.createdate ?? null,
      JSON.stringify(r),
      dt
    )
  );
  if (batch.length) await env.WAREHOUSE.batch(batch);
  return batch.length;
}

/** Split a .sql file into individual statements. */
function statements(sql: string): string[] {
  return sql
    .split(/;\s*$/m)
    .map((s) => s.trim())
    .filter(Boolean);
}

async function runSql(env: Env, sql: string): Promise<void> {
  for (const s of statements(sql)) {
    await env.WAREHOUSE.prepare(s).run();
  }
}

export async function runPipeline(env: Env, dt: string): Promise<void> {
  const staged = await stageContacts(env, dt);
  console.log(`[silver] staged ${staged} contacts for ${dt}`);

  await runSql(env, conformLeads);        // Bronze/stg → Silver
  console.log("[silver] conform_leads done");

  await runSql(env, martLeadPerformance); // Silver → Gold
  console.log("[gold] mart_lead_performance rebuilt");
}

export default {
  async scheduled(_event: ScheduledEvent, env: Env, ctx: ExecutionContext): Promise<void> {
    const dt = new Date().toISOString().slice(0, 10);
    ctx.waitUntil(runPipeline(env, dt));
  },

  // Manual trigger for local testing / backfills: GET /?dt=2026-10-01
  async fetch(req: Request, env: Env): Promise<Response> {
    const dt = new URL(req.url).searchParams.get("dt") ?? new Date().toISOString().slice(0, 10);
    await runPipeline(env, dt);
    return new Response(`pipeline run complete for ${dt}\n`);
  },
};
