# Medallion Marketing Data Pipeline — Demo

A compact, end-to-end demo of a **medallion architecture** (Bronze → Silver → Gold) for
marketing & revenue analytics, built on **Cloudflare Workers, D1, and R2**. It shows how raw
data from multiple ad, web, and CRM sources is ingested, conformed, and modeled into clean marts
that a dashboard or BI tool can read.

> ⚠️ **Demo project.** All data here is **synthetic** and all services are fictional
> ("Northwind Home Services"). It exists to demonstrate architecture and code patterns,
> not to run a real business.

---

## What it demonstrates

- **Medallion layering** — a disciplined Bronze/Silver/Gold split with clear contracts between layers.
- **Multi-source ingestion** — pluggable extractors (CRM, ad platforms, web analytics) landing raw payloads in object storage.
- **SQL-first transforms** — conform and model data with readable, version-controlled SQL.
- **Serverless, scheduled runtime** — Cloudflare Workers on cron triggers, D1 (SQLite) as the warehouse, R2 as the data lake.
- **Idempotent, auditable runs** — every layer is safe to re-run; loads are keyed and de-duplicated.

## Architecture

```mermaid
flowchart LR
    subgraph Sources
        A1[CRM API]
        A2[Ad Platform API]
        A3[Web Analytics API]
    end

    subgraph Bronze["🥉 Bronze — raw landing (R2)"]
        B[(Raw JSONL<br/>partitioned by source/date)]
    end

    subgraph Silver["🥈 Silver — conformed (D1)"]
        S1[slv_leads]
        S2[slv_ad_spend_daily]
        S3[slv_web_sessions]
    end

    subgraph Gold["🥇 Gold — marts (D1 views)"]
        G1[gld_lead_performance]
        G2[gld_channel_roi]
    end

    A1 & A2 & A3 -->|extractors| B
    B -->|conform| S1 & S2 & S3
    S1 & S2 & S3 -->|model| G1 & G2
    G1 & G2 --> D[Dashboard / BI]
```

### The layers

| Layer | Store | Purpose | Rule |
|-------|-------|---------|------|
| **Bronze** | R2 | Immutable raw capture, exactly as received | Never edited. Append-only, partitioned `source/dt=YYYY-MM-DD/` |
| **Silver** | D1 | Cleaned, typed, de-duplicated, conformed to a shared schema | One row per business entity; source quirks resolved here |
| **Gold** | D1 views | Business-facing marts & KPIs | Read-only, defined in SQL, consumed by dashboards |

## Tech stack

- **Cloudflare Workers** — extractors + transform runner, triggered on cron
- **Cloudflare D1** — SQLite warehouse (Silver tables, Gold views)
- **Cloudflare R2** — object store for the Bronze lake
- **TypeScript** — extractor & orchestration code
- **SQL** — all conform/model logic

## Project structure

```
medallion-pipeline-demo/
├── src/
│   ├── extractors/
│   │   └── crm-contacts.ts      # example: pull CRM contacts → Bronze (R2)
│   └── transform-runner.ts      # runs Silver + Gold SQL against D1
├── sql/
│   ├── silver/
│   │   └── conform_leads.sql    # Bronze → Silver conform
│   └── gold/
│       └── mart_lead_performance.sql  # Silver → Gold marts
├── data/sample/
│   └── crm_contacts.sample.jsonl  # synthetic raw payload
├── wrangler.jsonc               # Cloudflare config (placeholder IDs)
└── package.json
```

## How it runs (conceptually)

1. **Extract** — each Worker pulls from a source API and writes raw JSONL to R2 under
   `bronze/<source>/dt=<date>/`. Secrets (API tokens) are injected via `wrangler secret`, never committed.
2. **Conform (Silver)** — the transform runner reads the day's Bronze objects, then upserts typed,
   de-duplicated rows into D1 Silver tables using the SQL in `sql/silver/`.
3. **Model (Gold)** — Gold views in `sql/gold/` compose Silver tables into business marts
   (lead performance, channel ROI) that a dashboard reads directly.

Every step is **idempotent**: re-running a day re-derives the same result, so backfills and retries are safe.

## Running locally

```bash
npm install
# Authenticate wrangler to your own Cloudflare account, then:
npx wrangler d1 execute WAREHOUSE --local --file=sql/silver/conform_leads.sql
npx wrangler d1 execute WAREHOUSE --local --file=sql/gold/mart_lead_performance.sql
```

Set real resource IDs in `wrangler.jsonc` and provide secrets with:

```bash
npx wrangler secret put CRM_API_TOKEN
```

## License

MIT — see [LICENSE](LICENSE).
